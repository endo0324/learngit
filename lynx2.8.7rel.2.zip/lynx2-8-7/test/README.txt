ISO_LATIN1_test.html and iso8859-1.html are for testing the translation of
HTML entities with the character sets that are selectable via the 'o'ptions
menu.

TestComment.html and tabtest.html are for testing comment and TAB handling.

Any other files in this directory do not represent a test suite.  They
are used during program testing to track down odd and mysterious bugs.
